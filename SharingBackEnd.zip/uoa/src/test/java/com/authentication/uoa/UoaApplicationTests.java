package com.authentication.uoa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UoaApplicationTests {

	@Test
	void contextLoads() {
	}

}
